# Easy-KMS Test Package

This package contains all necessary components to run Easy-KMS tests on a target machine.

## Package Contents

- **Certificates**: CA, KME, and SAE certificates for mTLS testing
- **Source Code**: Complete Easy-KMS application
- **Test Scripts**: API testing tools and documentation
- **Configuration**: Nginx and application configuration files

## Quick Start

1. **Extract the package**:
   ```bash
   tar -xzf easy-kms-test-package-*.tar.gz
   cd easy-kms-test-package-*
   ```

2. **Set up Python environment**:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Configure environment**:
   ```bash
   cp env.example .env
   # Edit .env with your configuration
   ```

4. **Set up Nginx** (if using mTLS termination):
   ```bash
   sudo ./setup_nginx.sh
   ```

5. **Start the KME server**:
   ```bash
   ./start_kme.sh
   ```

6. **Run tests**:
   ```bash
   # Test local server
   ./test_kme_api.sh
   
   # Test remote server
   ./test_kme_api.sh --host <target-host> --port <target-port>
   ```

## Certificate Management

- **View certificates**: Check `certs/` directory
- **Reset certificates**: `./certs/tools/reset-certs.sh`
- **Regenerate certificates**: Use scripts in `certs/tools/`

## Test Options

The test script supports various options:
- `--host HOST`: Target KME server hostname/IP
- `--port PORT`: Target KME server port
- `--help`: Show help information

## Troubleshooting

1. **Certificate errors**: Ensure certificates are valid and have correct permissions
2. **Connection errors**: Check if target KME server is running and accessible
3. **Permission errors**: Ensure scripts have execute permissions

## Package Information

- **Created**: $(date)
- **Version**: $PACKAGE_VERSION
- **Source**: Easy-KMS $(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
