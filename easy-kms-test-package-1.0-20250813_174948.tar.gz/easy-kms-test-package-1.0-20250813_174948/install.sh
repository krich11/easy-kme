#!/bin/bash

# Easy-KMS Test Package Installer

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo -e "${BLUE}================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${CYAN}ℹ️  $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

main() {
    print_header "Easy-KMS Test Package Installation"
    
    # Check if running as root for nginx setup
    if [[ $EUID -eq 0 ]]; then
        print_warning "Running as root - will set up nginx configuration"
        SETUP_NGINX=true
    else
        print_info "Running as user - nginx setup will be skipped"
        SETUP_NGINX=false
    fi
    
    # Check Python
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is required but not installed"
        exit 1
    fi
    
    print_success "Python 3 found"
    
    # Create virtual environment
    print_info "Creating Python virtual environment..."
    python3 -m venv venv
    print_success "Virtual environment created"
    
    # Activate virtual environment and install dependencies
    print_info "Installing Python dependencies..."
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r requirements.txt
    print_success "Dependencies installed"
    
    # Set up environment file
    if [[ ! -f .env ]]; then
        print_info "Creating environment configuration..."
        cp env.example .env
        print_warning "Please edit .env file with your configuration"
    else
        print_info "Environment file already exists"
    fi
    
    # Set up nginx if running as root
    if [[ "$SETUP_NGINX" == "true" ]]; then
        print_info "Setting up nginx configuration..."
        ./setup_nginx.sh
        print_success "Nginx configuration set up"
    fi
    
    # Set permissions on certificates
    print_info "Setting certificate permissions..."
    chmod 600 certs/ca/ca.key
    chmod 600 certs/kme/kme.key
    chmod 600 certs/sae/*.key
    chmod 644 certs/ca/ca.crt
    chmod 644 certs/kme/kme.crt
    chmod 644 certs/sae/*.crt
    print_success "Certificate permissions set"
    
    print_header "Installation Complete"
    print_success "Easy-KMS test package is ready to use"
    echo
    print_info "Next steps:"
    echo "1. Edit .env file with your configuration"
    echo "2. Start the server: ./start_kme.sh"
    echo "3. Run tests: ./test_kme_api.sh"
    echo
    print_warning "If you need nginx setup, run: sudo ./setup_nginx.sh"
}

main "$@"
