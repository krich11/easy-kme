"""
Easy-KMS Server - ETSI GS QKD 014 Key Management Entity
"""

__version__ = "1.0.0"
__author__ = "Easy-KMS Contributors"
__description__ = "ETSI GS QKD 014 Key Management Entity (KME) Server" 