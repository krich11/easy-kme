"""
API routes for Easy-KMS server.
"""

from .routes import router

__all__ = ["router"] 